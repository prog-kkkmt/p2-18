from pyowm.owm import OWM
import requests


def get_id(s_city_name, gpp="RU"):
    appid = "3fd96f5c9c5ac865da969d95913e2196"
    try:
        res = requests.get("http://api.openweathermap.org/data/2.5/find",
                           params={'q': s_city_name, 'type': 'like', 'units': 'metric', 'lang': 'ru', 'APPID': appid})
        data = res.json()
        cities = ["{} ({})".format(d['name'], d['sys']['country'])
                  for d in data['list']]
        if gpp != 'RU':
            for i in range(len(cities)):
                if str(cities[i][-3:-1]) == gpp:
                    city_id = data['list'][i]['id']
                    dd = cities[i][-3:-1]
                    break
                else:
                    city_id = data['list'][1]['id']
                    dd = cities[i][-3:-1]
        else:
            city_id = data['list'][0]['id']
            dd = cities[0][-3:-1]
    except Exception as e:
        city_id = 524901;
        dd = "RU"
        pass
    return city_id, dd


def request_forecast(city_id):
    appid = "3fd96f5c9c5ac865da969d95913e2196"
    res = requests.get("http://api.openweathermap.org/data/2.5/forecast",
                       params={'id': city_id, 'units': 'metric', 'lang': 'BZ', 'APPID': appid})
    data = res.json()
    fa = []
    n = (data['city']['name'], data['city']['country'])
    for i in data['list']:
        e = (i['dt_txt'])[:16], '{0:+3.0f}'.format(i['main']['temp']),
        '{0:2.0f}'.format(i['wind']['speed']) + " м/с",
        i['weather'][0]['description']
        fa.append(e)
    if len(fa) < 48:
        m = ''.join(list(fa[0]))
        l = ('---------')
        m = int(m[11:13])
        e = 8 - (24 - m) // 3
        for i in range(e):
            fa.insert(0, l)
        for i in range((24 - m) // 3):
            fa.append(l)

    return fa


if __name__ == "__main__":
    pass
    # a = 'moscow'
    # d = 'ru'.upper()
    # if d != '':
    #     b = get_id(a, gpp=d)
    # else:
    #     b = get_id(a)
    # print(b)
    # f = request_forecast(b)
    # print(f)
    # print(len(f))
