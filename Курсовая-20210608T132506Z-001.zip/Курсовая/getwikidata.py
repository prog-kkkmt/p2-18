import requests
import re
from bs4 import BeautifulSoup


def get_data(url):
    rester = []
    poyas = ''
    plos = ''
    html = requests.get(url).text
    soup = BeautifulSoup(html, 'lxml')
    # Пояс
    try:
        h2 = soup.findAll('td', {"class": "plainlist"})
        h2 = str(h2)
        rs = ''.join(re.findall(r"UTC.{4,9}</", h2))
        for i in rs:
            if i != '<':
                poyas += i
            else:
                break
    except Exception:
        poyas = ''
    # Население
    try:
        naselenie = ''.join(re.findall(r"\d", rs[0]))
        h1 = soup.findAll('span', {"class": "nowrap"})
        h1 = str(h1)
        rs = re.findall(r">.{4,10}<su", h1)
        naselenie = ''.join(re.findall(r"\d", rs[0]))
    except Exception:
        naselenie = ''
    # Площадь
    try:
        h3 = soup.findAll('td', {"class": "plainlist"})
        h3 = str(h3)
        rs = ''.join(re.findall(r"\d{1,3},?.? ?\d{1,3} ? ?км²</", h3))
        rs.replace(' ', ' ')
        if rs != '':
            for i in rs:
                if i != '<':
                    plos += i
                else:
                    break
            plos = re.sub(r',', '.', plos)
        if rs == '':
            rs = ''.join(re.findall(r"\d{1,4},\d<", h3))
            for i in rs:
                if i != '<':
                    plos += i
                else:
                    break
            plos = re.sub(r',', '.', plos)
        if rs == '':
            rs = ''.join(re.findall(r"\d{1,4},\d{1,4}<", h3))
            for i in rs:
                if i != '<':
                    plos += i
                else:
                    break
            plos = re.sub(r',', '.', plos)
    except:
        plos = ''
    # Плотность
    try:
        plot = int(naselenie) / float(plos[0:-3])
        plot = round(plot, 2)
    except:
        plot = ''
    # Страна
    h5 = soup.findAll('th', {"class": "infobox-above"})
    h5 = str(h5)
    rs = ''.join(re.findall(r">\D{3,25}<", h5))
    ct = rs[1:-1]
    while '<' in ct:
        ct = ct[0:-1]
    try:
        h6 = soup.findAll('span', {"title": "Показать карту"})
        h6 = str(h6)
        la = ''.join(re.findall(r"l?o?n?=?ш?\.?\"-?\d{1,3}\.\d{1,10}\"", h6))
        lo = ''.join(re.findall(r"l?a?t?=?с?\.?\"-?\d{1,3}\.\d{1,10}\"", h6))
        while la.count('l') > 1:
            la = la[0:len(la) // 2]
        while lo.count('l') > 1:
            lo = lo[0:len(lo) // 2]
        coords = str(la) + ' ' + str(lo)
        while coords[0] != 'l':
            coords = coords[1:]
        while coords.count('"') > 4:
            coords = coords[0:-1]
        coords = coords[0:-1]
        la = ''.join(re.findall(r'lat=\"\d{1,3}\.?,?\d{1,10}', coords))
        lo = ''.join(re.findall(r'lon=\"\d{1,3}\.?,?\d{1,10}', coords))
        coords = str(la) + ' ' + str(lo)
        rs = re.findall(r">", h6)
    except Exception:
        coords = ''
    rester.append(str(naselenie))
    rester.append(str(plos))
    rester.append(str(plot))
    rester.append(str(ct))
    rester.append(str(coords))
    rester.append(str(poyas))
    return rester
