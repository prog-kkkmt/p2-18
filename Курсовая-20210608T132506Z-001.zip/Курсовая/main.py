import sys
import webbrowser
import weather as wk
from moonStyle import *
#import getwikidata as gwd


class MyWin(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.translate)
        self.ui.wikibut.clicked.connect(self.wiki_open)
        self.ui.comboBox.activated[str].connect(self.set_theme)
        self.ui.city2result.setText('Город')
        self.ui.enterbut.clicked.connect(self.find_owm)

    def wiki_open(self):
        webbrowser.open('https://ru.wikipedia.org/wiki/' + self.ui.finding.text())

    def translate(self):
        a = self.ui.info.text()
        if a == 'Информация':
            self.ui.people.setText('Population')
            self.ui.plos.setText('Area')
            self.ui.plot.setText('Density')
            self.ui.country1.setText('Country')
            self.ui.klim.setText('Lat|LON')
            self.ui.poyas.setText('Timezone')
            self.ui.info.setText('Information')
            self.ui.pushButton.setText('RU')
            self.ui.comment1.setText('Enter: City or Lat/Lon coordinates')
            self.ui.comment2.setText('Accurate country search in alpha order')
            if self.ui.city2result.text() == 'Город':
                self.ui.city2result.setText('City')

        else:
            self.ui.people.setText('Население')
            self.ui.plos.setText('Площадь')
            self.ui.plot.setText('Плотность')
            self.ui.country1.setText('Страна')
            self.ui.klim.setText('Ш|Д')
            self.ui.poyas.setText('Пояс')
            self.ui.info.setText('Информация')
            self.ui.pushButton.setText('ENG')
            self.ui.comment1.setText('Введите: Город либо Ш/Д координаты')
            self.ui.comment2.setText('Точный  поиск по странам в алф. порядке')
            if self.ui.city2result.text() == 'City':
                self.ui.city2result.setText('Город')
        pass

    def set_theme(self):
        if self.ui.comboBox.currentText() == 'moon':
            self.ui.comboBox.setStyleSheet("QComboBox::drop-down{\n"
                                           "image: url(./NewPrefix/point.png);\n"
                                           "padding-left:3px;\n"
                                           "}\n"
                                           "")
            self.ui.pushButton.setStyleSheet("QPushButton{\n"
                                             "border:0px solid rgb(12, 40, 71);\n"
                                             "background-color: rgb(21, 70, 113);\n"
                                             "border-radius:20px;\n"
                                             "color: rgb(255, 255, 255);\n"
                                             "}\n"
                                             "QPushButton:hover{\n"
                                             "background-color: rgb(255, 255, 0);\n"
                                             "color:black;\n"
                                             "}\n"
                                             "QPushButton:pressed{\n"
                                             "}")
            self.ui.enterbut_2.setStyleSheet("QPushButton{\n"
                                             "background-color: rgb(21, 70, 113);\n"
                                             "border:none;\n"
                                             "}\n"
                                             "")
            self.ui.enterbut.setStyleSheet("QPushButton{\n"
                                           "border:0px solid rgb(12, 40, 71);\n"
                                           "background-color: rgb(21, 70, 113);\n"
                                           "border-radius:20px;\n"
                                           "}\n"
                                           "QPushButton:hover{\n"
                                           "background-color:rgb(12, 40, 71);\n"
                                           "}\n"
                                           "QPushButton:pressed{\n"
                                           "}")
            self.ui.setcontry.setStyleSheet("QComboBox::drop-down{\n"
                                            "image: url(:/newPrefix/mpoint.png);\n"
                                            "padding-left:3px;\n"
                                            "}\n"
                                            "\n"
                                            "QComboBox:hover{\n"
                                            "image: none;\n"
                                            "}")
            self.ui.finding.setStyleSheet("QLineEdit{\n"
                                          "background-color:  rgb(21, 70, 113);\n"
                                          "border:2px solid rgb(206, 224, 255);\n"
                                          "border-color:rgb(21, 70, 113);\n"
                                          "border-radius:11px;\n"
                                          "color:rgb(222, 252, 255);\n"
                                          "padding-left:45px;\n"
                                          "}\n"
                                          "QLineEdit:hover{\n"
                                          "border-color: rgb(34, 115, 186);\n"
                                          "}\n"
                                          "QLineEdit:focus{\n"
                                          "border-color: rgb(255, 255, 127);\n"
                                          "}")
            self.ui.centralwidget.setStyleSheet("background-color: rgb(12, 40, 71);")

            self.ui.people.setStyleSheet("border:2px solid white;\n"
                                         "color:rgb(222, 252, 255);\n"
                                         "border-radius:10px;\n"
                                         "background-color: rgb(21, 70, 113);")
            self.ui.plos.setStyleSheet("border:2px solid white;\n"
                                       "color:rgb(222, 252, 255);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(21, 70, 113);")
            self.ui.plot.setStyleSheet("border:2px solid white;\n"
                                       "color:rgb(222, 252, 255);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(21, 70, 113);")
            self.ui.poyas.setStyleSheet("border:2px solid white;\n"
                                        "color:rgb(222, 252, 255);\n"
                                        "border-radius:10px;\n"
                                        "background-color: rgb(21, 70, 113);")
            self.ui.klim.setStyleSheet("border:2px solid white;\n"
                                       "color:rgb(222, 252, 255);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(21, 70, 113);")
            self.ui.country1.setStyleSheet("border:2px solid white;\n"
                                           "color:rgb(222, 252, 255);\n"
                                           "border-radius:10px;\n"
                                           "background-color: rgb(21, 70, 113);")
            self.ui.cityresult.setStyleSheet("background-color: rgb(21, 70, 113);\n"
                                             "color: rgb(255, 255, 255);\n"
                                             "border-radius:15px;\n"
                                             "padding-left:50px;\n"
                                             "padding-right:20px;")
            self.ui.peopleresult.setStyleSheet("color:rgb(235, 221, 24);\n"
                                               "border-bottom:2px solid white;\n"
                                               "padding-bottom:4px;")
            self.ui.plosresult.setStyleSheet("color:rgb(235, 221, 24);\n"
                                             "border-bottom:2px solid white;\n"
                                             "padding-bottom:4px;")
            self.ui.plotresult.setStyleSheet("color:rgb(235, 221, 24);\n"
                                             "border-bottom:2px solid white;\n"
                                             "padding-bottom:4px;")
            self.ui.countryresult.setStyleSheet("color:rgb(235, 221, 24);\n"
                                                "border-bottom:2px solid white;\n"
                                                "padding-bottom:4px;")
            self.ui.klimresult.setStyleSheet("color:rgb(235, 221, 24);\n"
                                             "border-bottom:2px solid white;\n"
                                             "padding-bottom:4px;")
            self.ui.poyasresult.setStyleSheet("color:rgb(235, 221, 24);\n"
                                              "border-bottom:2px solid white;\n"
                                              "padding-bottom:4px;")
            self.ui.info.setStyleSheet("color: rgb(255, 255, 255);\n"
                                       "background-color: rgb(21, 70, 113);\n"
                                       "border-radius:15px;")
            self.ui.wikibut.setStyleSheet("QPushButton{\n"
                                          "border:0px solid rgb(12, 40, 71);\n"
                                          "background-color: rgb(21, 70, 113);\n"
                                          "border-radius:20px;\n"
                                          "}\n"
                                          "QPushButton:hover{\n"
                                          "background-color: rgb(12, 40, 71);\n"
                                          "}\n"
                                          "QPushButton:pressed{\n"
                                          "}")
            self.ui.homeicon.setStyleSheet("border-radius:10px;\n"
                                           "background-color: rgb(21, 70, 113);")
            self.ui.city2result.setStyleSheet("color: rgb(255, 255, 255);\n"
                                              "border-bottom:2px solid rgb(21, 70, 113);\n"
                                              "background-color: rgb(21, 70, 113);\n"
                                              "padding-bottom:7px;\n"
                                              "border-radius:16px;")
            self.ui.scrollArear.setStyleSheet("background-color:rgb(21, 70, 113);\n"
                                              "color:white;\n"
                                              "")
            self.ui.dfmain.setStyleSheet("color:white;")
            self.ui.d11.setStyleSheet("background-color:none;")
            self.ui.data1.setStyleSheet("border:none;")
            self.ui.d02.setStyleSheet("background-color:none;")
            self.ui.data2.setStyleSheet("border:none;")
            self.ui.d5f.setStyleSheet("color:white;")
            self.ui.d35.setStyleSheet("color:white;")
            self.ui.d185.setStyleSheet("color:white;")
            self.ui.d05.setStyleSheet("background-color:none;;")
            self.ui.d185result.setStyleSheet("color:white;")
            self.ui.d215result.setStyleSheet("color:white;")
            self.ui.d35result.setStyleSheet("color:white;")
            self.ui.d155.setStyleSheet("color:white;")
            self.ui.d125result.setStyleSheet("color:white;")
            self.ui.d95.setStyleSheet("color:white;")
            self.ui.d215.setStyleSheet("color:white;")
            self.ui.d65result.setStyleSheet("color:white;")
            self.ui.d95result.setStyleSheet("color:white;")
            self.ui.d155result.setStyleSheet("color:white;")
            self.ui.data5.setStyleSheet("color:white;")
            self.ui.d65.setStyleSheet("color:white;")
            self.ui.d05result.setStyleSheet("color:white;")
            self.ui.d125.setStyleSheet("color:white;")
            self.ui.d03.setStyleSheet("background-color:none;")
            self.ui.d04.setStyleSheet("background-color:none;")
            self.ui.data3.setStyleSheet("border:none;")
            self.ui.data4.setStyleSheet("border:none;")
            self.ui.comment1.setStyleSheet("color: white;")
            self.ui.comment2.setStyleSheet("color: white;")
        if self.ui.comboBox.currentText() == 'oni':
            self.ui.centralwidget.setStyleSheet("background-color: rgb(255, 0, 0);")
            self.ui.people.setStyleSheet("border:2px solid rgb(0, 0, 0);\n"
                                         "color: rgb(0, 0, 0);\n"
                                         "border-radius:10px;\n"
                                         "background-color: rgb(255, 255, 255);")
            self.ui.finding.setStyleSheet("QLineEdit{\n"
                                          "background-color: rgb(0, 0, 0);\n"
                                          "border:2px solid rgb(206, 224, 255);\n"
                                          "border-color:rgb(21, 70, 113);\n"
                                          "border-radius:11px;\n"
                                          "color:rgb(222, 252, 255);\n"
                                          "padding-left:45px;\n"
                                          "}\n"
                                          "QLineEdit:hover{\n"
                                          "border-color: rgb(34, 115, 186);\n"
                                          "}\n"
                                          "QLineEdit:focus{\n"
                                          "border-color: rgb(255, 255, 127);\n"
                                          "}")
            self.ui.plos.setStyleSheet("border:2px solid rgb(0, 0, 0);\n"
                                       "color: rgb(0, 0, 0);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(255, 255, 255);")
            self.ui.plot.setStyleSheet("border:2px solid rgb(0, 0, 0);\n"
                                       "color: rgb(0, 0, 0);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(255, 255, 255);")
            self.ui.poyas.setStyleSheet("border:2px solid rgb(0, 0, 0);\n"
                                        "color: rgb(0, 0, 0);\n"
                                        "border-radius:10px;\n"
                                        "background-color: rgb(255, 255, 255);")
            self.ui.klim.setStyleSheet("border:2px solid rgb(0, 0, 0);\n"
                                       "color: rgb(0, 0, 0);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(255, 255, 255);")
            self.ui.country1.setStyleSheet("border:2px solid rgb(0, 0, 0);\n"
                                           "color: rgb(0, 0, 0);\n"
                                           "border-radius:10px;\n"
                                           "background-color: rgb(255, 255, 255);")
            self.ui.cityresult.setStyleSheet("color: rgb(255, 255, 255); \n"
                                             "background-color: rgb(0, 0, 0);\n"
                                             "border-radius:15px;")
            self.ui.peopleresult.setStyleSheet("color: rgb(255, 242, 55);\n"
                                               "border-bottom:2px solid rgb(0, 0, 0);\n"
                                               "padding-bottom:4px;")
            self.ui.plosresult.setStyleSheet("color: rgb(255, 242, 55);\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.plotresult.setStyleSheet("color: rgb(255, 242, 55);\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.countryresult.setStyleSheet("color: rgb(255, 242, 55);\n"
                                                "border-bottom:2px solid rgb(0, 0, 0);\n"
                                                "padding-bottom:4px;")
            self.ui.klimresult.setStyleSheet("color: rgb(255, 242, 55);\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.poyasresult.setStyleSheet("color: rgb(255, 242, 55);\n"
                                              "border-bottom:2px solid rgb(0, 0, 0);\n"
                                              "padding-bottom:4px;")
            self.ui.infoicon.setStyleSheet("background:none;\n"
                                           "")
            self.ui.info.setStyleSheet("color: rgb(255, 255, 255);\n"
                                       "background-color: rgb(0, 0, 0);\n"
                                       "border-radius:15px;")
            self.ui.wikibut.setStyleSheet("QPushButton{\n"
                                          "border:0px solid rgb(12, 40, 71);\n"
                                          "    background-color: rgb(0, 0, 0);\n"
                                          "border-radius:20px;\n"
                                          "}\n"
                                          "QPushButton:hover{\n"
                                          "background-color: rgb(255, 0, 0);\n"
                                          "}\n"
                                          "QPushButton:pressed{\n"
                                          "}")
            self.ui.homeicon.setStyleSheet("border-radius:10px;\n"
                                           "background-color: rgb(0, 0, 0);")
            self.ui.city2result.setStyleSheet("color: rgb(0, 0, 0);\n"
                                              "border-bottom:2px solid rgb(255, 255, 255);\n"
                                              "background-color: rgb(255, 255, 255);\n"
                                              "padding-bottom:7px;\n"
                                              "border-radius:16px;")
            self.ui.scrollArear.setStyleSheet("background-color: rgb(200, 0, 0);\n"
                                              "color:black;\n"
                                              "")
            self.ui.dfmain.setStyleSheet("color:white;")
            self.ui.d11.setStyleSheet("background-color:none;")
            self.ui.data1.setStyleSheet("border:none;")
            self.ui.d02.setStyleSheet("background-color:none;")
            self.ui.data2.setStyleSheet("border:none;")
            self.ui.d5f.setStyleSheet("color:white;")
            self.ui.d35.setStyleSheet("color:white;")
            self.ui.d185.setStyleSheet("color:white;")
            self.ui.d05.setStyleSheet("background-color:none;;")
            self.ui.d185result.setStyleSheet("color:white;")
            self.ui.d215result.setStyleSheet("color:white;")
            self.ui.d35result.setStyleSheet("color:white;")
            self.ui.d155.setStyleSheet("color:white;")
            self.ui.d125result.setStyleSheet("color:white;")
            self.ui.d95.setStyleSheet("color:white;")
            self.ui.d215.setStyleSheet("color:white;")
            self.ui.d65result.setStyleSheet("color:white;")
            self.ui.d95result.setStyleSheet("color:white;")
            self.ui.d155result.setStyleSheet("color:white;")
            self.ui.data5.setStyleSheet("color:white;")
            self.ui.d65.setStyleSheet("color:white;")
            self.ui.d05result.setStyleSheet("color:white;")
            self.ui.d125.setStyleSheet("color:white;")
            self.ui.d03.setStyleSheet("background-color:none;")
            self.ui.data3.setStyleSheet("border:none;")
            self.ui.d04.setStyleSheet("background-color:none;")
            self.ui.data4.setStyleSheet("border:none;")
            self.ui.setcontry.setStyleSheet("QComboBox::drop-down{\n"
                                            "image: url(:/newPrefix/mpoint.png);\n"
                                            "padding-left:3px;\n"
                                            "}\n"
                                            "\n"
                                            "QComboBox:hover{\n"
                                            "image: none;\n"
                                            "}")
            self.ui.enterbut.setStyleSheet("QPushButton{\n"
                                           "border:0px solid rgb(12, 40, 71);\n"
                                           "    background-color: rgb(0, 0, 0);\n"
                                           "border-radius:20px;\n"
                                           "}\n"
                                           "QPushButton:hover{\n"
                                           "background-color: rgb(255, 0, 0);\n"
                                           "}\n"
                                           "QPushButton:pressed{\n"
                                           "}")
            self.ui.comment1.setStyleSheet("color: rgb(0, 0, 0);")
            self.ui.comment2.setStyleSheet("color: rgb(0, 0, 0);")
            self.ui.enterbut_2.setStyleSheet("QPushButton{\n"
                                             "background-color: rgb(0, 0, 0);\n"
                                             "border:none;\n"
                                             "}\n"
                                             "")
            self.ui.pushButton.setStyleSheet("QPushButton{\n"
                                             "border:0px solid rgb(12, 40, 71);\n"
                                             "    background-color: rgb(255, 255, 255);\n"
                                             "border-radius:20px;\n"
                                             "color: rgb(0, 0, 0);\n"
                                             "}\n"
                                             "QPushButton:hover{\n"
                                             "background-color: rgb(255, 255, 0);\n"
                                             "\n"
                                             "}\n"
                                             "QPushButton:pressed{\n"
                                             "}")
            self.ui.comboBox.setStyleSheet("QComboBox::drop-down{\n"
                                           "image: url(:/newPrefix/opoint.png);\n"
                                           "padding-left:3px;\n"
                                           "}\n"
                                           "")
        if self.ui.comboBox.currentText() == 'pink':
            self.ui.centralwidget.setStyleSheet("background-color: rgb(255, 255, 255);")
            self.ui.pushButton.setStyleSheet("QPushButton{\n"
                                             "border:0px solid rgb(12, 40, 71);\n"
                                             "background-color: rgb(255, 17, 108);\n"
                                             "border-radius:20px;\n"
                                             "color: rgb(255, 255, 255);\n"
                                             "}\n"
                                             "QPushButton:hover{\n"
                                             "background-color: rgb(85, 85, 255);\n"
                                             "}\n"
                                             "QPushButton:pressed{\n"
                                             "}")
            self.ui.enterbut_2.setStyleSheet("QPushButton{\n"
                                             "background-color: rgb(255, 17, 108);\n"
                                             "border:none;\n"
                                             "}\n"
                                             "")
            self.ui.finding.setStyleSheet("QLineEdit{\n"
                                          "background-color: rgb(255, 17, 108);\n"
                                          "border:2px solid rgb(206, 224, 255);\n"
                                          "border-color:rgb(21, 70, 113);\n"
                                          "border-radius:11px;\n"
                                          "color:rgb(222, 252, 255);\n"
                                          "padding-left:45px;\n"
                                          "}\n"
                                          "QLineEdit:hover{\n"
                                          "border-color: rgb(34, 115, 186);\n"
                                          "}\n"
                                          "QLineEdit:focus{\n"
                                          "border-color: rgb(85, 85, 255);\n"
                                          "}")
            self.ui.people.setStyleSheet("border:2px solid black;\n"
                                         "color:rgb(222, 252, 255);\n"
                                         "border-radius:10px;\n"
                                         "background-color: rgb(255, 17, 108);")
            self.ui.plos.setStyleSheet("border:2px solid black;\n"
                                       "color:rgb(222, 252, 255);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(255, 17, 108);")
            self.ui.plot.setStyleSheet("border:2px solid black;\n"
                                       "color:rgb(222, 252, 255);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(255, 17, 108);")
            self.ui.poyas.setStyleSheet("border:2px solid black;\n"
                                        "color:rgb(222, 252, 255);\n"
                                        "border-radius:10px;\n"
                                        "background-color: rgb(255, 17, 108);")
            self.ui.klim.setStyleSheet("border:2px solid black;\n"
                                       "color:rgb(222, 252, 255);\n"
                                       "border-radius:10px;\n"
                                       "background-color: rgb(255, 17, 108);")
            self.ui.country1.setStyleSheet("border:2px solid black;\n"
                                           "color:rgb(222, 252, 255);\n"
                                           "border-radius:10px;\n"
                                           "background-color: rgb(255, 17, 108);")
            self.ui.cityresult.setStyleSheet("background-color: rgb(255, 17, 108);\n"
                                             "color: rgb(255, 255, 255);\n"
                                             "border-radius:15px;\n"
                                             "padding-left:50px;\n"
                                             "padding-right:20px;")
            self.ui.peopleresult.setStyleSheet("color: rgb(85, 85, 255);\n"
                                               "border-bottom:2px solid black;\n"
                                               "padding-bottom:4px;")
            self.ui.plosresult.setStyleSheet("color: rgb(85, 85, 255);\n"
                                             "border-bottom:2px solid black;\n"
                                             "padding-bottom:4px;")
            self.ui.plotresult.setStyleSheet("color: rgb(85, 85, 255);\n"
                                             "border-bottom:2px solid black;\n"
                                             "padding-bottom:4px;")
            self.ui.countryresult.setStyleSheet("color: rgb(85, 85, 255);\n"
                                                "border-bottom:2px solid black;\n"
                                                "padding-bottom:4px;")
            self.ui.klimresult.setStyleSheet("color: rgb(85, 85, 255);\n"
                                             "border-bottom:2px solid black;\n"
                                             "padding-bottom:4px;")
            self.ui.poyasresult.setStyleSheet("color: rgb(85, 85, 255);\n"
                                              "border-bottom:2px solid black;\n"
                                              "padding-bottom:4px;")
            self.ui.infoicon.setAutoFillBackground(False)
            self.ui.infoicon.setStyleSheet("background:none;\n"
                                           "")
            self.ui.info.setStyleSheet("color: rgb(255, 255, 255);\n"
                                       "background-color: rgb(255, 17, 108);\n"
                                       "border-radius:15px;")
            self.ui.wikibut.setStyleSheet("QPushButton{\n"
                                          "border:0px solid rgb(12, 40, 71);\n"
                                          "background-color: rgb(255, 17, 108);\n"
                                          "border-radius:20px;\n"
                                          "}\n"
                                          "QPushButton:hover{\n"
                                          "background-color: rgb(85, 85, 255);\n"
                                          "}\n"
                                          "QPushButton:pressed{\n"
                                          "}")
            self.ui.homeicon.setStyleSheet("border-radius:10px;\n"
                                           "background-color: rgb(255, 17, 108);")
            self.ui.city2result.setStyleSheet("color: rgb(255, 255, 255);\n"
                                              "border-bottom:2px solid white;\n"
                                              "background-color: rgb(255, 17, 108);\n"
                                              "padding-bottom:7px;\n"
                                              "border-radius:16px;")
            self.ui.scrollArear.setStyleSheet("background-color:rgb(255, 17, 108);\n"
                                              "color:white;\n"
                                              "")
            self.ui.dfmain.setStyleSheet("color:white;")
            self.ui.d11.setStyleSheet("background-color:none;")
            self.ui.data1.setStyleSheet("border:none;")
            self.ui.d02.setStyleSheet("background-color:none;")
            self.ui.data2.setStyleSheet("border:none;")
            self.ui.d5f.setStyleSheet("color:white;")
            self.ui.d35.setStyleSheet("color:white;")
            self.ui.d185.setStyleSheet("color:white;")
            self.ui.d05.setStyleSheet("background-color:none;;")
            self.ui.d185result.setStyleSheet("color:white;")
            self.ui.d215result.setStyleSheet("color:white;")
            self.ui.d35result.setStyleSheet("color:white;")
            self.ui.d155.setStyleSheet("color:white;")
            self.ui.d125result.setStyleSheet("color:white;")
            self.ui.d95.setStyleSheet("color:white;")
            self.ui.d215.setStyleSheet("color:white;")
            self.ui.d65result.setStyleSheet("color:white;")
            self.ui.d95result.setStyleSheet("color:white;")
            self.ui.d155result.setStyleSheet("color:white;")
            self.ui.data5.setStyleSheet("color:white;")
            self.ui.d65.setStyleSheet("color:white;")
            self.ui.d05result.setStyleSheet("color:white;")
            self.ui.d125.setStyleSheet("color:white;")
            self.ui.d03.setStyleSheet("background-color:none;")
            self.ui.data3.setStyleSheet("border:none;")
            self.ui.d04.setStyleSheet("background-color:none;")
            self.ui.data4.setStyleSheet("border:none;")
            self.ui.setcontry.setStyleSheet("QComboBox::drop-down{\n"
                                            "image: url(:/newPrefix/rpoint.png);\n"
                                            "padding-left:3px;\n"
                                            "}\n"
                                            "\n"
                                            "QComboBox:hover{\n"
                                            "image: none;\n"
                                            "}")
            self.ui.enterbut.setStyleSheet("QPushButton{\n"
                                           "border:0px solid rgb(12, 40, 71);\n"
                                           "background-color: rgb(255, 17, 108);\n"
                                           "border-radius:20px;\n"
                                           "}\n"
                                           "QPushButton:hover{\n"
                                           "background-color: rgb(85, 85, 255);\n"
                                           "}\n"
                                           "QPushButton:pressed{\n"
                                           "}")
            self.ui.comment1.setStyleSheet("color: black;")
        if self.ui.comboBox.currentText() == 'hub':
            self.ui.centralwidget.setStyleSheet("background-color: rgb(209, 209, 209);")
            self.ui.finding.setStyleSheet("QLineEdit{\n"
                                          "background-color: rgb(54, 54, 54);\n"
                                          "border:2px solid rgb(206, 224, 255);\n"
                                          "border-color:rgb(21, 70, 113);\n"
                                          "border-radius:11px;\n"
                                          "color:white;\n"
                                          "padding-left:45px;\n"
                                          "}\n"
                                          "QLineEdit:hover{\n"
                                          "border-color: rgb(34, 115, 186);\n"
                                          "}\n"
                                          "QLineEdit:focus{\n"
                                          "border-color:rgb(227, 227, 227);\n"
                                          "}")
            self.ui.people.setStyleSheet("color: rgb(232, 232, 232);\n"
                                         "background-color: rgb(67, 67, 67);\n"
                                         "border-radius:15px;")
            self.ui.plos.setStyleSheet("color: rgb(232, 232, 232);\n"
                                       "background-color: rgb(67, 67, 67);\n"
                                       "border-radius:15px;")
            self.ui.plot.setStyleSheet("color: rgb(232, 232, 232);\n"
                                       "background-color: rgb(67, 67, 67);\n"
                                       "border-radius:15px;")
            self.ui.poyas.setStyleSheet("color: rgb(232, 232, 232);\n"
                                        "background-color: rgb(67, 67, 67);\n"
                                        "border-radius:15px;")
            self.ui.klim.setStyleSheet("color: rgb(232, 232, 232);\n"
                                       "background-color: rgb(67, 67, 67);\n"
                                       "border-radius:15px;")
            self.ui.country1.setStyleSheet("color: rgb(232, 232, 232);\n"
                                           "background-color: rgb(67, 67, 67);\n"
                                           "border-radius:15px;")
            self.ui.cityresult.setStyleSheet("color: rgb(232, 232, 232);\n"
                                             "background-color: rgb(67, 67, 67);\n"
                                             "border-radius:15px;")
            self.ui.peopleresult.setStyleSheet("color: white;\n"
                                               "border-bottom:2px solid rgb(0, 0, 0);\n"
                                               "padding-bottom:4px;")
            self.ui.plosresult.setStyleSheet("color: white;\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.plotresult.setStyleSheet("color: white;\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.countryresult.setStyleSheet("color: white;\n"
                                                "border-bottom:2px solid rgb(0, 0, 0);\n"
                                                "padding-bottom:4px;")
            self.ui.klimresult.setStyleSheet("color: white;\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.poyasresult.setStyleSheet("color: white;\n"
                                              "border-bottom:2px solid rgb(0, 0, 0);\n"
                                              "padding-bottom:4px;")
            self.ui.infoicon.setStyleSheet("background:none;\n"
                                           "")
            self.ui.info.setStyleSheet("color: rgb(232, 232, 232);\n"
                                       "background-color: rgb(67, 67, 67);\n"
                                       "border-radius:15px;")
            self.ui.wikibut.setStyleSheet("QPushButton{\n"
                                          "border:0px solid rgb(12, 40, 71);\n"
                                          "    background-color: rgb(54, 54, 54);\n"
                                          "border-radius:20px;\n"
                                          "}\n"
                                          "QPushButton:hover{\n"
                                          "background-color: rgb(0, 0, 0);\n"
                                          "}\n"
                                          "QPushButton:pressed{\n"
                                          "}")
            self.ui.homeicon.setStyleSheet("background-color: rgb(67, 67, 67);")
            self.ui.city2result.setStyleSheet("color: rgb(232, 232, 232);\n"
                                              "border-bottom:0px solid rgb(255, 255, 255);\n"
                                              "background-color: rgb(67, 67, 67);\n"
                                              "padding-bottom:7px;\n"
                                              "border-radius:16px;")
            self.ui.scrollArear.setStyleSheet("background-color: rgb(54, 54, 54);\n"
                                              "color: rgb(227, 227, 227);\n"
                                              "")
            self.ui.d11.setStyleSheet("background-color:none;")
            self.ui.data1.setStyleSheet("border:none;")
            self.ui.d02.setStyleSheet("background-color:none;")
            self.ui.data2.setStyleSheet("border:none;")
            self.ui.d5f.setStyleSheet("color:white;")
            self.ui.d185.setStyleSheet("color:white;")
            self.ui.d185result.setStyleSheet("color:white;")
            self.ui.d125result.setStyleSheet("color:white;")
            self.ui.d95.setStyleSheet("color:white;")
            self.ui.d215.setStyleSheet("color:white;")
            self.ui.d65result.setStyleSheet("color:white;")
            self.ui.d95result.setStyleSheet("color:white;")
            self.ui.d155result.setStyleSheet("color:white;")
            self.ui.data5.setStyleSheet("color:white;")
            self.ui.d65.setStyleSheet("color:white;")
            self.ui.d05result.setStyleSheet("color:white;")
            self.ui.d125.setStyleSheet("color:white;")
            self.ui.d03.setStyleSheet("background-color:none;")
            self.ui.data3.setStyleSheet("border:none;")
            self.ui.d04.setStyleSheet("background-color:none;")
            self.ui.data4.setStyleSheet("border:none;")
            self.ui.setcontry.setStyleSheet("QComboBox::drop-down{\n"
                                            "image: url(:/newPrefix/dpoint.png);\n"
                                            "padding-left:3px;\n"
                                            "}\n"
                                            "\n"
                                            "QComboBox:hover{\n"
                                            "image: none;\n"
                                            "}")
            self.ui.enterbut.setStyleSheet("QPushButton{\n"
                                           "border:0px solid rgb(12, 40, 71);\n"
                                           "    background-color: rgb(54, 54, 54);\n"
                                           "border-radius:20px;\n"
                                           "}\n"
                                           "QPushButton:hover{\n"
                                           "background-color: rgb(0, 0, 0);\n"
                                           "}\n"
                                           "QPushButton:pressed{\n"
                                           "}")
            self.ui.comment1.setStyleSheet("color: rgb(67, 67, 67);")
            self.ui.comment2.setStyleSheet("color: rgb(67, 67, 67);")
            self.ui.enterbut_2.setStyleSheet("QPushButton{\n"
                                             "background-color: rgb(54, 54, 54);\n"
                                             "border:none;\n"
                                             "}\n"
                                             "")
            self.ui.pushButton.setStyleSheet("QPushButton{\n"
                                             "border:0px solid rgb(12, 40, 71);\n"
                                             "    background-color: rgb(67, 67, 67);\n"
                                             "border-radius:20px;\n"
                                             "    color: rgb(227, 227, 227);\n"
                                             "}\n"
                                             "QPushButton:hover{\n"
                                             "background-color: rgb(27, 27, 27);\n"
                                             "\n"
                                             "}\n"
                                             "QPushButton:pressed{\n"
                                             "}")
            self.ui.comboBox.setStyleSheet("QComboBox::drop-down{\n"
                                           "image: url(:/newPrefix/dpoint.png);\n"
                                           "padding-left:3px;\n"
                                           "}\n"
                                           "")
        if self.ui.comboBox.currentText() == 'porn':
            self.ui.poyasresult.setStyleSheet("color: white;\n"
                                              "border-bottom:2px solid rgb(0, 0, 0);\n"
                                              "padding-bottom:4px;")
            self.ui.infoicon.setStyleSheet("background:none;\n"
                                           "")
            self.ui.info.setStyleSheet("color: rgb(0, 0, 0);\n"
                                       "background-color: rgb(255, 124, 37);\n"
                                       "border-radius:15px;")

            self.ui.finding.setStyleSheet("QLineEdit{\n"
                                          "background-color: rgb(54, 54, 54);\n"
                                          "border:2px solid rgb(206, 224, 255);\n"
                                          "border-color:rgb(21, 70, 113);\n"
                                          "border-radius:11px;\n"
                                          "color:white;\n"
                                          "padding-left:45px;\n"
                                          "}\n"
                                          "QLineEdit:hover{\n"
                                          "border-color: rgb(34, 115, 186);\n"
                                          "}\n"
                                          "QLineEdit:focus{\n"
                                          "border-color: rgb(255, 124, 27);\n"
                                          "}")

            self.ui.cityresult.setStyleSheet("color: rgb(255, 255, 255);\n"
                                             "background-color: rgb(255, 124, 37);\n"
                                             "border-radius:15px;")
            self.ui.wikibut.setStyleSheet("QPushButton{\n"
                                          "border:0px solid rgb(12, 40, 71);\n"
                                          "    background-color: rgb(54, 54, 54);\n"
                                          "border-radius:20px;\n"
                                          "}\n"
                                          "QPushButton:hover{\n"
                                          "background-color: rgb(255, 124, 27);\n"
                                          "}\n"
                                          "QPushButton:pressed{\n"
                                          "}")
            self.ui.homeicon.setStyleSheet("border-radius:10px;\n"
                                           "background-color: rgb(255, 124, 27);")
            self.ui.city2result.setStyleSheet("color: rgb(0, 0, 0);\n"
                                              "border-bottom:0px solid rgb(255, 255, 255);\n"
                                              "background-color: rgb(255, 124, 27);\n"
                                              "padding-bottom:7px;\n"
                                              "border-radius:16px;")
            self.ui.scrollArear.setStyleSheet("background-color: rgb(54, 54, 54);\n"
                                              "color:white;\n"
                                              "")
            self.ui.dfmain.setStyleSheet("color:white;")
            self.ui.centralwidget.setStyleSheet("background-color: rgb(27, 27, 27);")
            self.ui.d11.setStyleSheet("background-color:none;")
            self.ui.data1.setStyleSheet("border:none;")
            self.ui.d02.setStyleSheet("background-color:none;")
            self.ui.data2.setStyleSheet("border:none;")
            self.ui.d5f.setStyleSheet("color:white;")
            self.ui.d35.setStyleSheet("color:white;")
            self.ui.d185.setStyleSheet("color:white;")
            self.ui.d05.setStyleSheet("background-color:none;;")
            self.ui.d185result.setStyleSheet("color:white;")
            self.ui.d215result.setStyleSheet("color:white;")
            self.ui.d35result.setStyleSheet("color:white;")
            self.ui.d155.setStyleSheet("color:white;")
            self.ui.d125result.setStyleSheet("color:white;")
            self.ui.d95.setStyleSheet("color:white;")
            self.ui.d215.setStyleSheet("color:white;")
            self.ui.d65result.setStyleSheet("color:white;")
            self.ui.d95result.setStyleSheet("color:white;")
            self.ui.d155result.setStyleSheet("color:white;")
            self.ui.data5.setStyleSheet("color:white;")
            self.ui.d65.setStyleSheet("color:white;")
            self.ui.d05result.setStyleSheet("color:white;")
            self.ui.d125.setStyleSheet("color:white;")
            self.ui.d03.setStyleSheet("background-color:none;")
            self.ui.data3.setStyleSheet("border:none;")
            self.ui.d04.setStyleSheet("background-color:none;")
            self.ui.data4.setStyleSheet("border:none;")
            self.ui.setcontry.setStyleSheet("QComboBox::drop-down{\n"
                                            "image: url(:/newPrefix/mpoint.png);\n"
                                            "padding-left:3px;\n"
                                            "}\n"
                                            "\n"
                                            "QComboBox:hover{\n"
                                            "image: none;\n"
                                            "}")
            self.ui.enterbut.setStyleSheet("QPushButton{\n"
                                           "border:0px solid rgb(12, 40, 71);\n"
                                           "    background-color: rgb(54, 54, 54);\n"
                                           "border-radius:20px;\n"
                                           "}\n"
                                           "QPushButton:hover{\n"
                                           "background-color:rgb(255, 124, 27);\n"
                                           "}\n"
                                           "QPushButton:pressed{\n"
                                           "}")
            self.ui.comment1.setStyleSheet("color: white;")
            self.ui.comment2.setStyleSheet("color: white;")
            self.ui.enterbut_2.setStyleSheet("QPushButton{\n"
                                             "background-color: rgb(54, 54, 54);\n"
                                             "border:none;\n"
                                             "}\n"
                                             "")
            self.ui.pushButton.setStyleSheet("QPushButton{\n"
                                             "border:0px solid rgb(12, 40, 71);\n"
                                             "background-color: rgb(255, 124, 27);\n"
                                             "border-radius:20px;\n"
                                             "color:white;\n"
                                             "}\n"
                                             "QPushButton:hover{\n"
                                             "background-color: rgb(27, 27, 27);\n"
                                             "\n"
                                             "}\n"
                                             "QPushButton:pressed{\n"
                                             "}")
            self.ui.comboBox.setStyleSheet("QComboBox::drop-down{\n"
                                           "image: url(:/newPrefix/ppoint.png);\n"
                                           "padding-left:3px;\n"
                                           "}\n"
                                           "")
            self.ui.peopleresult.setStyleSheet("color: white;\n"
                                               "border-bottom:2px solid rgb(0, 0, 0);\n"
                                               "padding-bottom:4px;")
            self.ui.poyasresult.setStyleSheet("color: white;\n"
                                              "border-bottom:2px solid rgb(0, 0, 0);\n"
                                              "padding-bottom:4px;")
            self.ui.plosresult.setStyleSheet("color: white;\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.plotresult.setStyleSheet("color: white;\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.klimresult.setStyleSheet("color: white;\n"
                                             "border-bottom:2px solid rgb(0, 0, 0);\n"
                                             "padding-bottom:4px;")
            self.ui.countryresult.setStyleSheet("color: white;\n"
                                                "border-bottom:2px solid rgb(0, 0, 0);\n"
                                                "padding-bottom:4px;")
            self.ui.klim.setStyleSheet("color: black;\n"
                                       "background-color: rgb(255, 124, 37);\n"
                                       "border-radius:15px;")
            self.ui.plos.setStyleSheet("color: black;\n"
                                       "background-color: rgb(255, 124, 37);\n"
                                       "border-radius:15px;")
            self.ui.plot.setStyleSheet("color: black;\n"
                                       "background-color: rgb(255, 124, 37);\n"
                                       "border-radius:15px;")
            self.ui.people.setStyleSheet("color: black;\n"
                                         "background-color: rgb(255, 124, 37);\n"
                                         "border-radius:15px;")
            self.ui.poyas.setStyleSheet("color: black;\n"
                                        "background-color: rgb(255, 124, 37);\n"
                                        "border-radius:15px;")
            self.ui.country1.setStyleSheet("color: black;\n"
                                           "background-color: rgb(255, 124, 37);\n"
                                           "border-radius:15px;")

    def find_owm(self):
        try:
            lagr = self.ui.setcontry.currentText()
            if lagr == '':
                lagr = 'RU'
            a = self.ui.finding.text().capitalize()
            r, m = wk.get_id(a, lagr.upper())
            if r == 524901 and (a != 'Moscow' and a != 'Москва'):
                ress = ['---------', '---------', '---------', '---------', '---------', '---------', '---------',
                        '---------', '---------', '---------', '---------', '---------', '---------', '---------',
                        '---------', '---------', '---------', '---------', '---------', '---------', '---------',
                        '---------', '---------', '---------', '---------', '---------', '---------', '---------',
                        '---------', '---------', '---------', '---------', '---------', '---------', '---------',
                        '---------', '---------', '---------', '---------', '---------', '---------', '---------',
                        '---------', '---------']
                m = ''
            else:
                ress = wk.request_forecast(r)
            # ss = gwd.get_data('https://ru.wikipedia.org/wiki/' + self.ui.finding.text())
            self.ui.data1.setText('Сегодня:')
            self.ui.data2.setText('Завтра:')
            self.ui.data3.setText('Послезавтра:')
            self.ui.data4.setText('Через 3 дня:')
            self.ui.data5.setText('Через 4 дня:')
            # self.ui.peopleresult.setText(ss[0])
            # self.ui.plosresult.setText(ss[1])
            # self.ui.plotresult.setText(ss[2])
            # self.ui.countryresult.setText(m)
            # self.ui.klimresult.setText(ss[4])
            # self.ui.poyasresult.setText(ss[5])
            self.ui.d11result.setText('Темп:' + ress[0][1] + '°C')
            self.ui.d31result.setText('Темп:' + ress[1][1] + '°C')
            self.ui.d61result.setText('Темп:' + ress[2][1] + '°C')
            self.ui.d91result.setText('Темп:' + ress[3][1] + '°C')
            self.ui.d121result.setText('Темп:' + ress[4][1] + '°C')
            self.ui.d151result.setText('Темп:' + ress[5][1] + '°C')
            self.ui.d181result.setText('Темп:' + ress[6][1] + '°C')
            self.ui.d211result.setText('Темп:' + ress[7][1] + '°C')
            self.ui.d02result.setText('Темп:' + ress[8][1] + '°C')
            self.ui.d32result.setText('Темп:' + ress[9][1] + '°C')
            self.ui.d62result.setText('Темп:' + ress[10][1] + '°C')
            self.ui.d92result.setText('Темп:' + ress[11][1] + '°C')
            self.ui.d122result.setText('Темп:' + ress[12][1] + '°C')
            self.ui.d152result.setText('Темп:' + ress[13][1] + '°C')
            self.ui.d182result.setText('Темп:' + ress[14][1] + '°C')
            self.ui.d212result.setText('Темп:' + ress[15][1] + '°C')
            self.ui.d03result.setText('Темп:' + ress[16][1] + '°C')
            self.ui.d33result.setText('Темп:' + ress[17][1] + '°C')
            self.ui.d63result.setText('Темп:' + ress[18][1] + '°C')
            self.ui.d93result.setText('Темп:' + ress[19][1] + '°C')
            self.ui.d123result.setText('Темп:' + ress[20][1] + '°C')
            self.ui.d153result.setText('Темп:' + ress[21][1] + '°C')
            self.ui.d183result.setText('Темп:' + ress[22][1] + '°C')
            self.ui.d213result.setText('Темп:' + ress[23][1] + '°C')
            self.ui.d04result.setText('Темп:' + ress[24][1] + '°C')
            self.ui.d34result.setText('Темп:' + ress[25][1] + '°C')
            self.ui.d64result.setText('Темп:' + ress[26][1] + '°C')
            self.ui.d94result.setText('Темп:' + ress[27][1] + '°C')
            self.ui.d124result.setText('Темп:' + ress[28][1] + '°C')
            self.ui.d154result.setText('Темп:' + ress[29][1] + '°C')
            self.ui.d184result.setText('Темп:' + ress[30][1] + '°C')
            self.ui.d214result.setText('Темп:' + ress[31][1] + '°C')
            self.ui.d05result.setText('Темп:' + ress[32][1] + '°C')
            self.ui.d35result.setText('Темп:' + ress[33][1] + '°C')
            self.ui.d65result.setText('Темп:' + ress[34][1] + '°C')
            self.ui.d95result.setText('Темп:' + ress[35][1] + '°C')
            self.ui.d125result.setText('Темп:' + ress[36][1] + '°C')
            self.ui.d155result.setText('Темп:' + ress[37][1] + '°C')
            self.ui.d185result.setText('Темп:' + ress[38][1] + '°C')
            self.ui.d215result.setText('Темп:' + ress[39][1] + '°C')
            self.ui.d215result.setText('Темп:' + ress[40][1] + '°C')
            self.ui.cityresult.setText(self.ui.finding.text().capitalize() + '  ' + m)
            self.ui.city2result.setText(self.ui.finding.text().capitalize() + '  ' + m)
        except Exception:

            self.ui.cityresult.setText(self.ui.finding.text().capitalize() + '  ' + m)
            self.ui.city2result.setText(self.ui.finding.text().capitalize() + '  ' + m)
            pass


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    myapp = MyWin()
    myapp.show()
    sys.exit(app.exec_())
