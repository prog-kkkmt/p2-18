# Импорт модуля Tkinter
from tkinter import *

def file():
    f = open('test.txt', 'w')
    f.write(en.get())
    f.close()
'''Создание функции записи информации с поля ввода в файл
'''

# Создание объекта окна верхнего уровня (на нём будут распологаться все элементы
root = Tk()

# Размера окна и координатов расположения курсора мыши
root.geometry("200x150+700+300")

# Замена заднего фона на заданный вами цвет
root["bg"] = "grey"

# Создание текстовой метки
lb1 = Label(root,text="Текстовая метка", background="grey")

# Задание местоположение текстовой метки
lb1.place(x=2, y=16)

# Создание поля ввода
en = Entry(root, width=15)

# Задание местоположение поля ввода
en.place(x=100, y=18)

# Создание кнопки и подключение к функции
b = Button(root, text='Отправить',background="#555", foreground="#ccc", command=file)
# Задание местоположение кнопки
b.place(x=112, y=45)

# Создание переключателя и задание местоположения
rb1 = Radiobutton(root, text="2",background="grey", value=1).place(x=150, y=120)
rb2 = Radiobutton(root, text="1",background="grey", value=2).place(x=150, y=90)

# Создание поля с галочкой и задание местоположения
сb1 = Checkbutton(root, text="Проверка",background="grey",).place(x=50, y=110)

# Создание масcива
mas = ('10 000', '20 000', '30 000', '40 000', '50 000')
# Создание поля выбора и задание местоположения
sb = Spinbox(root, width=10, values=mas).place(x=10, y=80)

# Обновление событий
root.mainloop()
