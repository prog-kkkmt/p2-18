a=float(input())
print(a**3)
print(6*a**2)
