import math
a=float(input())
b=3.14
print (a*b)
