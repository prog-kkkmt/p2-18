r=float(input())
print(2*3.14*r)
print(3.14*r**2)
