a=float(input())
b=float(input())
print(round(a*b)**0.5)
