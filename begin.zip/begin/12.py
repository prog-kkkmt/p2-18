a=float(input())
b=float(input())
c=(a**2+b**2)**0.5
p=a+b+c
print(c)
print(p)
