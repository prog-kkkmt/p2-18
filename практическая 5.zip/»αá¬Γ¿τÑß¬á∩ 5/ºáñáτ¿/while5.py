len = 0
while int(input()) != 0:
    len += 1
print(len)
