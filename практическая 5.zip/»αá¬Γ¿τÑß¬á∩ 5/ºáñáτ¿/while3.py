n=int(input())
b=2
power=1
while b<= n:
    b*= 2
    power+=1
print(power-1,b//2)
