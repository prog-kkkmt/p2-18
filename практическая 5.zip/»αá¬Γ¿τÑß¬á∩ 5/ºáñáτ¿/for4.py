sum = 0

for i in range(10):
    n = int(input())
    sum+= n
print(sum)
