x = int(input())
if (0 < x < 6):
    if x == 1:
        print("Плохо")
    elif x == 2:
        print("Неудовлетворительно")
    elif x == 3:
        print("Удовретворительно")
    elif x == 4:
        print("Хорошо")
    elif x == 5:
        print("Отлично")
else:
    print("Ошибка")
