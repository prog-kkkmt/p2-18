x=int(input())
res=x%2==0
print(res)
