a = int(input())
b = a > 0
print(b)
