if x > 0:
    x = x + 1
    print(x)
elif x < 0:
    x=x-2
    print(x)
else:
    x = 10
    print(x)
