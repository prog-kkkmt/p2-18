a = int(input())
b = x * x
