x = int(input("Введите число: "))
if x > 0:
    x = x + 1
    print(x)
else:
    x = x - 2
    print(x)
